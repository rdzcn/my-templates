import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component {
  render () {
    return (
      <div className="app">
         <h1>Rails with React</h1>
      </div>
    ) 
  } 
}  

export default App;
